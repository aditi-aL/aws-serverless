'use strict';

module.exports.calSum = (event, context, callback)  => {
    let add = 0;
     let arr = [2,3,5,7] 
     
     for(var i = 0; i < arr.length; i++) {
         add += arr[i]
     }
   
   const response = {
     statusCode: 200,
     body: JSON.stringify({
       message: 'OK',
         total: add
     }),
   };
   
   callback(null, response)
  }